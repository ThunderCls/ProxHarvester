Free Windows 10 Icons

This free icon set contains 100 icons.
File formats: EPS, PNG, and SVG

SOURCE
This package is from Six Revisions.
  Web address: http://sixrevisions.com/free-icons/free-windows-10-icons/

DESIGNED BY
The contents of this package was created by Icons8.
  Web address: https://icons8.com/

TERMS OF USE
These icons are free to use and is licensed under the Good Boy License
  Web address: https://icons8.com/good-boy-license/

ATTRIBUTION
Attribution is not required.

If you'd like to provide attribution, please use the following HTML code:

<a href="http://sixrevisions.com/free-icons/free-windows-10-icons/" target="_blank">Free Windows 10 Icons</a> designed by <a href="https://icons8.com/" target="_blank">Icons8</a>